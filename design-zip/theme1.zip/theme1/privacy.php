<?php include('include/header.php'); ?>
<div class="inner_header">
  <div class="container">
    <h1>Privacy Policy</h1>
    <ul class="ul_set">
      <li><a href="index.php">Home</a></li>
      <li><span>Privacy Policy</span></li>
    </ul>
  </div>
</div>
<section class="abbout_uss pad_b">
  <div class="container">

    <div class="row justify-content-center">
      <div class="col-sm-8">
      <div class="conten_set ">
    <p>
      

Any study material as provided by CSEPracticals is confidential and is not liable to uploaded on any 3rd party website / gdrive or Posted on social media platform without prior permissions from CSEPracticals

    </p>
    <p>
      

We dont collect / store any of your personal details like email address, phone number

    </p>
    </div>
      </div>
    </div>
    
  </div>
</section>

<?php include('include/footer.php'); ?>