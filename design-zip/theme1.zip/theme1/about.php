<?php include('include/header.php'); ?>
<div class="inner_header">
  <div class="container">
    <h1>About Us</h1>
    <ul class="ul_set">
      <li><a href="index.php">Home</a></li>
      <li><span>About Us</span></li>
    </ul>
  </div>
</div>
<section class="abbout_uss pad_b">
  <div class="container">

    <div class="row justify-content-center">
      <div class="col-sm-8">
      <div class="conten_set ">
      <p>
         Welcome to CSEPracticals, an OnlineCourse offering Website in the field of Operating Systems, Networking, Linux System Programming and Several Coding Projects. We offer only Development based Projects, no DS/ALGO/CP. 
      </p>
    </div>
      </div>
    </div>
    
  </div>
</section>

<?php include('include/footer.php'); ?>