<?php include('include/header.php'); ?>
<div class="inner_header">
  <div class="container">
    <h1>Terms & Conditions</h1>
    <ul class="ul_set">
      <li><a href="index.php">Home</a></li>
      <li><span>Terms & Conditions</span></li>
    </ul>
  </div>
</div>
<section class="abbout_uss pad_b">
  <div class="container">

    <div class="row justify-content-center">
      <div class="col-sm-8">
      <div class="conten_set ">
      <p>
        

Purchase of the courses are refundable only under exceptional conditions, the CSEPracticals shall have full authority to decide if refund request is legitimate and need to be processed.

      </p>
      <p>
        

Illegal copy or distribution of the courses is strictly prohibited, if found indulge in any such activities shall cancel your subscription from any future services being delivered by CSEPracticals

      </p>
      <p>
        

Pls maintain proper decorum in our telegram group, violation of any policy shall cancel your membership from our telegram technical groups.

      </p>
    </div>
      </div>
    </div>
    
  </div>
</section>

<?php include('include/footer.php'); ?>