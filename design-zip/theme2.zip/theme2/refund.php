<?php include('include/header.php'); ?>
<div class="inner_header">
  <div class="container">
    <h1>Refund Cancellation Policy</h1>
    <ul class="ul_set">
      <li><a href="index.php">Home</a></li>
      <li><span>Refund Cancellation Policy</span></li>
    </ul>
  </div>
</div>
<section class="abbout_uss pad_b">
  <div class="container">

    <div class="row justify-content-center">
      <div class="col-sm-8">
      <div class="conten_set ">
      <p>
        There is no refund if courses are purchased in accordance with the offers. Pls contact us at <a href="mailto:csepracticals@gmail.com">csepracticals@gmail.com</a> Or whatsapp to settle any concerns Or Purchases done by mistake. If Courses are purchased directly from hosting site ( udemy ), then refund period is 30 days with 100% refund. All Courses are provided with lifetime access.
      </p>
      <p><b>Place of Operations</b>  :  Bangalore, Karnataka</p>
    </div>
      </div>
    </div>
    
  </div>
</section>

<?php include('include/footer.php'); ?>